const playerData = [
     {
        name: 'JOKK',
        veriferData: {
            name: 'TheTemmieX',
            url: 'https://www.youtube.com/watch?v=PfwUfAYfubM'
        },
        
        victorsData: []
    },

 {
        name: 'controllable seizure',
        veriferData: {
            name: 'kitcat43129',
            url: 'https://drive.google.com/file/d/1epfZHclq3xZNQk2S5ldJgg7xFs6Ypf4E/view?usp=sharing'
        },

        victorsData: []
    },


    {
        name: 'UnMaded',
        veriferData: {
            name: 'Nazorro_',
            url: 'https://youtu.be/EqH-2yR9TVE'
        },

        victorsData: []
    },

    {
        name: 'amethyst challenge',
        veriferData: {
            name: 'ItzMiny',
            url: 'https://drive.google.com/file/d/1kKKranmpiC_ij_tbjdWsPMQOfrfrmFCC/view?usp=sharing'
        },
        
        victorsData: [
            {
                name: 'Nazorro_',
                url: 'https://youtu.be/hsKJNIeewow'
            },
        ]
    },

    {
        name: 'Boon',
        veriferData: {
            name: 'ExactZ',
            url: ''
        },
        
        victorsData: [
            {
                name: 'Nazorro_',
                url: 'https://youtu.be/bpxCIJuQHf0'
            },

            {
                name: 'ItzMiny',
                url: 'https://drive.google.com/file/d/1_V3RDPktOdGY48jqoRt2xr30UxDlnCKI/view?usp=sharing'
            },
        ]
    },

    {
        name: 'STEREO BUFFNESS',
        veriferData: {
            name: 'Utochka',
            url: 'https://drive.google.com/file/d/1h2XQk5uGef9-yFFod7WGCVNvENS9fMiC/view?usp=sharing'
        },
        
        victorsData: [
            {
                name: 'Nazorro_',
                url: 'https://youtu.be/0ag0FUi_-6M'
            },

            {
                name: 'ItzMiny',
                url: 'https://drive.google.com/file/d/1FIPYwHqJ_bjJExCkD0c_q_v0-82g6JXN/view?usp=sharing'
            },

            {
                name: 'maxvelvi33',
                url: 'https://drive.google.com/file/d/1jcutkk-t6K_VA7u8B8Bc8-uOMT1Ctmi4/view?usp=sharing'
            },
        ]
    },

    {
        name: 'untitled unnamed',
        veriferData: {
            name: 'ExactZ',
            url: 'https://drive.google.com/file/d/1AsbJLBpJ4g1Lo3kGOSfOxrhP6sgoFRzN/view?usp=sharing'
        },
        
        victorsData: [
            {
                name: 'Nazorro_',
                url: 'https://youtu.be/u6KL3hgp4ik'
            },
        ]
    },

    {
        name: 'The Egoist',
        veriferData: {
            name: 'Setiop',
            url: ''
        },
        
        victorsData: []
    },

    {
        name: 'green wave buff (UNRATED)',
        veriferData: {
            name: 'ExactZ',
            url: 'https://drive.google.com/file/d/1-Vh840fLEjSLq1-6vJg2ArKCicp7jPuQ/view?usp=sharing'
        },
        
        victorsData: []
    },

    {
        name: 'Clutter God',
        veriferData: {
            name: 'ExactZ',
            url: ''
        },
        
        victorsData: [
            {
                name: 'ItzMiny',
                url: 'https://drive.google.com/file/d/10ZkBzlgHc52kiVmE-bqrvZLMvNUV2zYI/view?usp=sharing'
            },
        ]
    },

    {
        name: 'Green Wave',
        veriferData: {
            name: 'ferx1n56',
            url: ''
        },
        
        victorsData: []
    },

    {
        name: 'Top 1',
        veriferData: {
            name: 'ferx1n56',
            url: ''
        },
        
        victorsData: [
            {
                name: 'ItzMiny',
                url: 'https://drive.google.com/file/d/1FmkUcflodRyM1tIESJYKFe-ivngl_gae/view?usp=sharing'
            }
        ]
    },

    {
        name: 'beZ doZi',
        veriferData: {
            name: 'Beist',
            url: ''
        },
        
        victorsData: [
            {
                name: 'Utochka',
                url: 'https://drive.google.com/file/d/1D7IddgqMNrpm4cBmUclwhD3vf7S_6hPX/view?usp=sharing'
            },

            {
                name: 'CsGoDimas30',
                url: 'https://youtu.be/cGrINQTWrmc'
            },

            {
                name: 'Imacube',
                url: 'https://youtu.be/Fxaj1x3ty_0'
            },
        ]
    },

    {
        name: 'The Prodigy',
        veriferData: {
            name: 'Setiop',
            url: ''
        },
        
        victorsData: [
            {
                name: 'CsGoVERNITEDima',
                url: 'https://youtu.be/ukXaQYSrCzQ'
            },

            {
                name: 'ImaCube',
                url: 'https://youtu.be/aVlg5j91RuM'
            }
        ]
    },

    {
        name: 'Undecored Chaos',
        veriferData: {
            name: 'Setiop',
            url: ''
        },
        
        victorsData: [
            {
                name: 'Imacube',
                url: 'https://www.youtube.com/watch?v=yZ7_bCtUlY0'
            }
        ]
    },

    {
        name: 'HELL',
        veriferData: {
            name: 'CsGoVERNITEDima',
            url: 'https://youtu.be/Dw1BUCmhwkI?t=1730'
        },
        
        victorsData: []
    },

    {
        name: 'dep',
        veriferData: {
            name: 'ItzMiny',
            url: 'https://drive.google.com/file/d/1m8UsLYeUAwi4cShadT7hX-ft6RD-MenB/view?usp=sharing'
        },
        
        victorsData: []
    },

    {
        name: 'Creo Circles',
        veriferData: {
            name: 'PELM3N',
            url: ''
        },
        
        victorsData: [
            {
                name: 'CsGoVERNITEDima',
                url: 'https://youtu.be/N0Yvy0h449U?t=983'
            },

            {
                name: 'Imacube',
                url: 'https://youtu.be/sgmb61IEbwI?si=USOSVtMx-9o-xvFO'
            },
        ]
    },

    {
        name: 'Im with you',
        veriferData: {
            name: 'Nazorro',
            url: 'https://youtu.be/lOnsQi8pu7c'
        },
        
        victorsData: []
    },

    {
        name: 'X',
        veriferData: {
            name: 'Nzcir',
            url: ''
        },
        
        victorsData: [
            {
                name: 'CSGOVERNITEDIMAS30',
                url: 'https://youtu.be/00mCRhcMWhw?si=YF8zMQ24c2r0ZvZJ'
            },
        ]
    },
];
