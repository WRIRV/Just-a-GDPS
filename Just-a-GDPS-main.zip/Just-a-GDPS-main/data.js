const levelData = [ //место в топе зависит от положения в массиве
    {
        name: 'UnMaded (UNRATED)',
        author: 'royalGG',
        id: 257
    },

    {
        name: 'amethyst challenge',
        author: 'ItzMiny',
        id: 165
    },

    {
        name: 'Boon',
        author: 'ExactZ',
        id: 117
    },

    {
        name: 'STEREO BUFFNESS',
        author: 'Utochka',
        id: 181
    },

    {
        name: 'untitled unnamed',
        author: 'ExactZ',
        id: 217
    },

    {
        name: 'The Egoist',
        author: 'Setiop',
        id: 211
    },

    {
        name: 'green wave buff (UNRATED)',
        author: 'ExactZ',
        id: 181
    },

    {
        name: 'Clutter God',
        author: 'ExactZ',
        id: 104
    },

    {
        name: 'Green Wave',
        author: 'ferx1n56',
        id: 144
    },

    {
        name: 'Top 1',
        author: 'ferx1n56',
        id: 147
    },

    {
        name: 'beZ doZi',
        author: 'Beist',
        id: 129
    },

    {
        name: 'The Prodigy',
        author: 'Setiop',
        id: 199
    },

    {
        name: 'Undecored Chaos',
        author: 'Setiop',
        id: 155
    },
];
