const levelData = [ //место в топе зависит от положения в массиве
    {
        name: 'UnMaded',
        author: 'royalGG',
        id: 257
    },

 {
        name: 'controllable seizure',
        author: 'kitcat43129',
        id: 718
    },


    {
        name: 'dep',
        author: 'ItzMiny',
        id: 327
    },

    {
        name: 'amethyst challenge',
        author: 'ItzMiny',
        id: 165
    },

    {
        name: 'untitled unnamed',
        author: 'ExactZ',
        id: 217
    },

    {
        name: 'JOKK',
        author: 'TheTemmieX',
        id: 558
    },

    {
        name: 'Boon',
        author: 'ExactZ',
        id: 117
    },

    {
        name: 'STEREO BUFFNESS',
        author: 'Utochka',
        id: 173
    },

    {
        name: 'Im with you',
        author: 'RoyalGG',
        id: 478
    },

    {
        name: 'The Egoist',
        author: 'Setiop',
        id: 211
    },

    {
        name: 'Clutter God',
        author: 'ExactZ',
        id: 104
    },

    {
        name: 'Top 1',
        author: 'ferx1n56',
        id: 147
    },

    {
        name: 'HELL',
        author: 'CsGoVERNITEDima',
        id: 314
    },

    {
        name: 'X',
        author: 'Nzcir',
        id: 434
    },

    {
        name: 'The Prodigy',
        author: 'Setiop',
        id: 199
    },

    {
        name: 'Creo Circles',
        author: 'PELM3N',
        id: 251
    },

    {
        name: 'Undecored Chaos',
        author: 'Setiop',
        id: 155
    },

    {
        name: 'beZ doZi',
        author: 'Beist',
        id: 129
    },
];
